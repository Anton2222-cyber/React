import React from 'react';
import StopWatch from './components/StopWatch';


class App extends React.Component {

  
  render() {
    return (
      <article>
        <h1>Секундомір онлайн</h1>
       <StopWatch/>
      </article >
    );
  }
}

export default App;
