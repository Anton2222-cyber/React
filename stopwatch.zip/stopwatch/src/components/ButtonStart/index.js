import React, { Component } from 'react';
import styles from './ButtonStart.module.css';
class ButtonStart extends Component {
  render() {
   
    return (
      <button onClick={this.props.startClick} className={styles.btnStart}>СТАРТ</button>
    );
  }
}

export default ButtonStart;
