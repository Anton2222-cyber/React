import React, { Component } from 'react';
import styles from './StopWatch.module.css';
import ButtonStart from '../ButtonStart';
import ButtonPause from '../ButtonPause';
import ButtonCircle from '../ButtonCircle';
import ButtonContinue from '../ButtonContinue';
import ButtonReset from '../ButtonReset';
import DataTableStopWatch from '../DataTableStopWatch';
import SpanWatchGeneral from '../SpanWatchGeneral';
import SpanWatch from '../SpanWatch';

function DataRow(index, circleTime, elapsedTime, nowTime) {
  this.index = index;
  this.circleTime = circleTime;
  this.elapsedTime = elapsedTime;
  this.nowTime = nowTime;
}

class StopWatch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      time: new Date(0, 0, 0, 0, 0, 0),
      timeCircle: new Date(0, 0, 0, 0, 0, 0),
      isVisibleStartBtn: true,
      isVisiblePauseBtn: false,
      isVisibleCircleBtn: false,
      isVisibleContinueBtn: false,
      isVisibleResetBtn: false,
      isVisibleDataTable: false

    };
    this.idInterval = null;
    this.idIntervalCircle = null;
    this.dataRows = [];
    this.countRows = 1;
  }
  // formatTimeWithMilliseconds = (date, isGeneral) => {
  //   const hours = String(date.getHours()).padStart(2, '0');
  //   const minutes = String(date.getMinutes()).padStart(2, '0');
  //   const seconds = String(date.getSeconds()).padStart(2, '0');
  //   const milliseconds = String(Math.floor(date.getMilliseconds() / 100)).padStart(1, '0');

  //   // return `${hours}:${minutes}:${seconds}:${milliseconds}`;
  //   if (isGeneral)
  //     return <span className={styles.spanWatchGeneral}>{hours}:{minutes}:{seconds}<span className={styles.milisecondGeneral}>{milliseconds}</span></span>
  //   return <span className={styles.spanWatch}>{hours}:{minutes}:{seconds}<span className={styles.milisecond}>{milliseconds}</span></span>
  // }
  formatTimeWithMilliseconds = (date) => {
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    const milliseconds = String(Math.floor(date.getMilliseconds() / 100)).padStart(1, '0');

    return `${hours}:${minutes}:${seconds}:${milliseconds}`;

  }

  componentWillUnmount() {
    this.stop();
  }
  start = () => {

    if (this.idInterval === null) {
      //isOf = false;
      this.idInterval = setInterval(() => {
        const { time } = this.state;
        //const newTime = new Date(time.getTime() + 1000);
        time.setMilliseconds(time.getMilliseconds() + 100);
        this.setState({ time: time })
      }, 100);
    }
  }
  startCircl = () => {
    if (this.idIntervalCircle === null) {
      //isOf = false;
      this.idIntervalCircle = setInterval(() => {
        const { timeCircle } = this.state;
        //const newTime = new Date(time.getTime() + 1000);
        timeCircle.setMilliseconds(timeCircle.getMilliseconds() + 100);
        this.setState({ timeCircle: timeCircle })
      }, 100);
    }
  }

  stop = () => {
    clearTimeout(this.idInterval);
    this.idInterval = null;

    clearTimeout(this.idIntervalCircle);
    this.idIntervalCircle = null;
  }
  reset = () => {
    this.stop();
    this.setState({
      time: new Date(0, 0, 0, 0, 0, 0),
      timeCircle: new Date(0, 0, 0, 0, 0, 0)
    });
  }
  startClick = () => {
    this.start();
    this.startCircl();
    this.setState({
      isVisibleStartBtn: !this.state.isVisibleStartBtn,
      isVisiblePauseBtn: !this.state.isVisiblePauseBtn,
      isVisibleCircleBtn: !this.state.isVisibleCircleBtn
    });
  }
  pauseClick = () => {
    this.stop();
    this.setState({
      isVisiblePauseBtn: !this.state.isVisiblePauseBtn,
      isVisibleCircleBtn: !this.state.isVisibleCircleBtn,
      isVisibleContinueBtn: !this.state.isVisibleContinueBtn,
      isVisibleResetBtn: !this.state.isVisibleResetBtn
    });
  }
  resetClick = () => {
    this.reset();
    this.circleClick();
    this.setState({
      isVisibleContinueBtn: !this.state.isVisibleContinueBtn,
      isVisibleResetBtn: !this.state.isVisibleResetBtn,
      isVisibleStartBtn: !this.state.isVisibleStartBtn
    });
  }
  continueClick = () => {
    this.start();
    this.startCircl();
    this.setState({
      isVisibleContinueBtn: !this.state.isVisibleContinueBtn,
      isVisibleResetBtn: !this.state.isVisibleResetBtn,
      isVisiblePauseBtn: !this.state.isVisiblePauseBtn,
      isVisibleCircleBtn: !this.state.isVisibleCircleBtn
    });
  }

  addLeadingZero = (number) => {
    return number < 10 ? `0${number}` : number;
  }

  circleClick = () => {
    const currentDate = new Date();
    const day = currentDate.getDate();
    const month = currentDate.getMonth() + 1; // Місяці в JavaScript нумеруються з 0, тому додаємо 1.
    const year = currentDate.getFullYear();
    const hours = currentDate.getHours();
    const minutes = currentDate.getMinutes();

    const formattedDate = `${this.addLeadingZero(day)}/${this.addLeadingZero(month)}/${year}`;
    const formattedTime = `${this.addLeadingZero(hours)}:${this.addLeadingZero(minutes)}`;
    const currentDateTimeString = `${formattedDate} - ${formattedTime}`;
    // let stringCurrentDate = currentDate.getDay() + '/' + (currentDate.getMonth() + 1) + '/' + currentDate.getFullYear() + ' - ' + currentDate.getHours() + ':' + currentDate.getMinutes();

    this.dataRows.push(new DataRow(
      this.countRows++,
      this.formatTimeWithMilliseconds(this.state.timeCircle),
      // this.state.timeCircle.toLocaleTimeString('en-GB'),
      this.formatTimeWithMilliseconds(this.state.time),
      //this.state.time.toLocaleTimeString('en-GB'),
      currentDateTimeString
    ));
    this.setState({
      isVisibleDataTable: true
    });

    clearTimeout(this.idIntervalCircle);
    this.idIntervalCircle = null;
    this.setState({
      timeCircle: new Date(0, 0, 0, 0, 0, 0)
    });
    if (this.idInterval !== null)
      this.startCircl();
  }
  deleteHistory = () => {
    this.countRows = 1;
    this.setState({
      isVisibleDataTable: false
    });
    this.dataRows.splice(0, this.dataRows.length);

  }

  render() {
    return (
      <div >
        <div className={styles.clockface}>
          <SpanWatchGeneral date={this.state.time} />
          <SpanWatch date={this.state.timeCircle} />
          {/* {this.formatTimeWithMilliseconds(this.state.time,true)}
          {this.formatTimeWithMilliseconds(this.state.timeCircle,false)} */}
          {/* <span className={styles.spanWatchGeneral}>{this.formatTimeWithMilliseconds(this.state.time)}</span> */}
          {/* <span className={styles.spanWatch}>{this.formatTimeWithMilliseconds(this.state.timeCircle)}</span> */}
        </div>
        <div className={styles.btnContainer}>
          {this.state.isVisibleStartBtn && <ButtonStart startClick={this.startClick} />}
          {this.state.isVisiblePauseBtn && <ButtonPause pauseClick={this.pauseClick} />}
          {this.state.isVisibleCircleBtn && <ButtonCircle circleClick={this.circleClick} />}
          {this.state.isVisibleContinueBtn && <ButtonContinue continueClick={this.continueClick} />}
          {this.state.isVisibleResetBtn && <ButtonReset resetClick={this.resetClick} />}
        </div>
        {this.state.isVisibleDataTable && <DataTableStopWatch dataRows={this.dataRows} deleteHistory={this.deleteHistory} />}
      </div>
    );
  }
}

export default StopWatch;
