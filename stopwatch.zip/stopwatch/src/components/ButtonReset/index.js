import React, { Component } from 'react';
import styles from './ButtonReset.module.css';
class ButtonReset extends Component {
  render() {
    return (
      <>
        <button onClick={this.props.resetClick} className={styles.btnReset}>СКИНУТИ</button>
      </>
    );
  }
}

export default ButtonReset;
