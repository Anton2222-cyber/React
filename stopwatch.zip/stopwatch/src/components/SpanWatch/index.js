import React, { Component } from 'react';
import styles from './SpanWatch.module.css'
class SpanWatch extends Component {
  render() {
    const { date } = this.props;
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    const milliseconds = String(Math.floor(date.getMilliseconds() / 100)).padStart(1, '0');
    return (
       <span className={styles.spanWatch}>{hours}:{minutes}:{seconds}<span className={styles.milisecond}>{milliseconds}</span></span>
    );
  }
}

export default SpanWatch;
