import React, { Component } from 'react';
import styles from './ButtonContinue.module.css'
class ButtonContinue extends Component {
  render() {
    return (
      <>
        <button onClick={this.props.continueClick}  className={styles.btnContinue}>ПРОДОВЖИТИ</button>
      </>
    );
  }
}

export default ButtonContinue;
