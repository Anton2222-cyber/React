import React, { Component } from 'react';
import styles from './ButtonCircle.module.css';
class ButtonCircle extends Component {
  render() {
    return (
      <>
        <button onClick={this.props.circleClick} className={styles.btnCircle}>КРУГ</button>
      </>
    );
  }
}

export default ButtonCircle;
