import React, { Component } from 'react';
import styles from './ButtonPause.module.css';
class ButtonPause extends Component {
  render() {
    return (
      <>
        <button onClick={this.props.pauseClick} className={styles.btnPause}>ПАУЗА</button>
      </>
    );
  }
}

export default ButtonPause;
