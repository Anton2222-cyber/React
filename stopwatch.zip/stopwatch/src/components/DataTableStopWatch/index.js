import React, { Component } from 'react';
import styles from './DataTableStopWatch.module.css'
class DataTableStopWatch extends Component {
  render() {
    const { dataRows } = this.props;
    const renderRows = dataRows.map(row =>
      <tr key={row.index}>
        <td>{row.index}</td>
        <td>{row.circleTime}</td>
        <td>{row.elapsedTime}</td>
        <td>{row.nowTime}</td>
      </tr>);
    return (
      <div className={styles.centerDiv}>
        <h2 className={styles.txtHeaderTable}>Данні секундоміра</h2>
        <table>
          <thead>
            <tr className={styles.trLine}>
              <th>#</th>
              <th>Час проходження кругу</th>
              <th>Вичерпаний час</th>
              <th>Поточний час</th>
            </tr>
          </thead>
          <tbody>
            {renderRows}
          </tbody>
        </table>
        <button onClick={this.props.deleteHistory} className={styles.btnDeleteHistory}>ВИДАЛИТИ ДАННІ</button>
      </div>
    );
  }
}

export default DataTableStopWatch;
