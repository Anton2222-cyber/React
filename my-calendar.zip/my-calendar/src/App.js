import logo from './logo.svg';
import './App.css';
import Calendar from './components/Calendar';

function App() {
  return (
    <article className='backgroundSite'>
      <h1 className='hCalendar'>Календар</h1>
      <Calendar />
    </article>

  );
}

export default App;
