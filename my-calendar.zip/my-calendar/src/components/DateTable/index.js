import React, { Component } from 'react';
import styles from './DateTable.module.scss';
import UpArrowIcon from '../UpArrowIcon';
import DownArrowIcon from '../DownArrowIcon';
import { endOfMonth, subMonths, format, getDay, getDaysInMonth, addDays, getDate } from 'date-fns';
import ukLocale from 'date-fns/locale/uk';
import NumberCalendar from '../NumberCalendar';


class DateTable extends Component {

  compareDates = (date1, date2) => {
    const year1 = date1.getFullYear();
    const month1 = date1.getMonth();
    const day1 = date1.getDate();

    const year2 = date2.getFullYear();
    const month2 = date2.getMonth();
    const day2 = date2.getDate();

    if (year1 === year2 && month1 === month2 && day1 === day2) {
      return true; // Дати однакові
    }
    return false;
  }

  render() {
     const { currentDateTime, choseNowMonth} = this.props;
    // const choseNowMonth = true;
    // const currentDateTime = new Date(2023, 8, 30);

    const lastDayOfPreviousMonth = endOfMonth(subMonths(currentDateTime, 1)); // Останній день попереднього місяця
    const dayOfMonth = lastDayOfPreviousMonth.getDate();
    const dayOfWeekNumber = getDay(lastDayOfPreviousMonth); // 0 - неділя, 1 - понеділок, ..., 6 - субота

    let k = 1;
    let kForTd = 1;
    let renderBody = [];
    renderBody.push(
      <tr key={k++}>
        <td key={kForTd++}>Пн</td>
        <td key={kForTd++}>Вт</td>
        <td key={kForTd++}>Ср</td>
        <td key={kForTd++}>Чт</td>
        <td key={kForTd++}>Пт</td>
        <td key={kForTd++}>Сб</td>
        <td key={kForTd++}>Нд</td>
      </tr>
    );


    let tdForAdd = [];
    let count = 0;
    for (let i = dayOfMonth - dayOfWeekNumber + 1; i <= dayOfMonth; i++) {
      tdForAdd.push(
        <td key={kForTd++}><NumberCalendar number={i} isCurrent={false} isCurrentMonth={false} /></td>
      );
      count++;
    }

    // const daysInMonth = getDaysInMonth(currentDateTime);
    let howManyAdd = 7 - count;
    let currentDayAdd = 1;
    for (; currentDayAdd <= howManyAdd; currentDayAdd++) {
      let isCurrentDayNow = false;
      //
      if (this.compareDates(new Date(currentDateTime.getFullYear(),currentDateTime.getMonth(),currentDayAdd), currentDateTime) && choseNowMonth) {
        isCurrentDayNow = true;
      }

      tdForAdd.push(
        <td key={kForTd++}><NumberCalendar number={currentDayAdd} isCurrent={isCurrentDayNow} isCurrentMonth={true} /></td>
      );
      count++;
    }
    renderBody.push(
      <tr key={k++}>
        {tdForAdd}
      </tr>
    );

    let currentDateAdd = new Date(currentDateTime.getFullYear(), currentDateTime.getMonth(), currentDayAdd - 1);
    let isCurrentMonthNow = true;
    for (; count < 42;) {
      let tdForAdd = [];
      for (let i = 0; i < 7; i++) {
        currentDateAdd = addDays(currentDateAdd, 1);
        let isCurrentDayNow = false;
        if (getDate(currentDateAdd) === 1) {
          isCurrentMonthNow = false;
        }

        // console.log(currentDateAdd.toLocaleDateString());
        // console.log(currentDateAdd.toLocaleDateString());

        if (this.compareDates(currentDateAdd, currentDateTime) && choseNowMonth) {
          isCurrentDayNow = true;
        }
        tdForAdd.push(
          <td key={kForTd++}><NumberCalendar number={getDate(currentDateAdd)} isCurrent={isCurrentDayNow} isCurrentMonth={isCurrentMonthNow} /></td>
        );

        count++;
      }
      renderBody.push(
        <tr key={k++}>
          {tdForAdd}
        </tr>
      );
    }



    return (
      <div className={styles.dataContainer}>
        <div className={styles.headerTableContainer}>
          <h2 className={styles.headerDate}>{format(currentDateTime, 'LLLL yyyy', { locale: ukLocale })}</h2>
          <div className={styles.arrowContainer}>
            <UpArrowIcon minusMonthsToTable={this.props.minusMonthsToTable} />
            <DownArrowIcon addMonthsToTable={this.props.addMonthsToTable} />
          </div>
        </div>
        <div >
          <table className={styles.table}>
            <tbody>
              {renderBody}
            </tbody>
          </table>
        </div>
      </div>


    );
  }
}

export default DateTable;
