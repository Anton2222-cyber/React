import React, { Component } from 'react';
import styles from './UpArrowIcon.module.scss';

class UpArrowIcon extends Component {

  render() {
    return (
      <div className={styles.arrow}>
        <svg onClick={this.props.minusMonthsToTable} xmlns="http://www.w3.org/2000/svg"  fill="none" width='26' height='26' viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
          <path  strokeLinecap="round" strokeLinejoin="round" d="M4.5 15.75l7.5-7.5 7.5 7.5" />
        </svg>
      </div>

    );
  }
}

export default UpArrowIcon;


