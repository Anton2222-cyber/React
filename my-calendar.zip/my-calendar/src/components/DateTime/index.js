import React, { Component } from 'react';
import styles from './DateTime.module.scss';
import { format } from 'date-fns';
import ukLocale from 'date-fns/locale/uk';
class DateTime extends Component {
  render() {
    const{currentDateTime,returnToCurrentMonth}=this.props;
    return (
      <div className={styles.timeContainer}>
        <h2 className={styles.timeHeader} >{format(currentDateTime, 'HH:mm:ss')}</h2>
        <h2 className={styles.dateHeader} onClick={returnToCurrentMonth}>{format(currentDateTime, 'dd MMMM yyyy р.', { locale: ukLocale })}</h2>
      </div>
      
    );
  }
}

export default DateTime;
