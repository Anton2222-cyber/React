import React, { Component } from 'react';
import styles from './Calendar.module.scss';
import DateTime from '../DateTime';
import DateTable from '../DateTable';
import { addMonths, endOfMonth, subMonths } from 'date-fns';

class Calendar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentDateTime: new Date(),
      dateForTable: new Date(),
      nowMonth: true
    }

  }
  componentDidMount() {
    this.interval = setInterval(() => {
      this.setState({
        currentDateTime: new Date()
      });
    }, 1000);
  }


  componentWillUnmount() {
    clearInterval(this.interval);
  }
  compareDates = (date1, date2) => {
    const year1 = date1.getFullYear();
    const month1 = date1.getMonth();


    const year2 = date2.getFullYear();
    const month2 = date2.getMonth();


    if (year1 === year2 && month1 === month2) {
      return true; // Дати однакові
    }
    return false;
  }
  addMonthsToTable = () => {
    
    const newDate = addMonths(this.state.dateForTable, 1);
    const newDateEndOfMonth = endOfMonth(newDate);
    this.setNowMonth(newDateEndOfMonth);
  }
  minusMonthsToTable = () => {
    const newDate = subMonths(this.state.dateForTable, 1);
    const newDateEndOfMonth = endOfMonth(newDate);
    this.setNowMonth(newDateEndOfMonth);
  }
  setNowMonth=(newDateEndOfMonth)=>{
    const { currentDateTime } = this.state;
    if (this.compareDates(currentDateTime, newDateEndOfMonth)) {   
      this.setState({
        dateForTable: currentDateTime,
        nowMonth: true
      });
    }else{
      this.setState({
        dateForTable: newDateEndOfMonth,
        nowMonth: false
      });
    }
  }
  returnToCurrentMonth=()=>{
    this.setState({
      dateForTable: this.state.currentDateTime,
      nowMonth: true
    });
  }
  render() {
    const { currentDateTime, dateForTable, nowMonth} = this.state;
    
    return (
      <article className={styles.calendarBody}>       
        <DateTime currentDateTime={currentDateTime} returnToCurrentMonth={this.returnToCurrentMonth}/>
        <DateTable currentDateTime={dateForTable} choseNowMonth={nowMonth} addMonthsToTable={this.addMonthsToTable} minusMonthsToTable ={this.minusMonthsToTable} />
      </article>
    );
  }
}

export default Calendar;
