import React, { Component } from 'react';
import styles from './NumberCalendar.module.scss';
import classNames from 'classnames';

class NumberCalendar extends Component {
  render() {
    const { number, isCurrent,isCurrentMonth } = this.props;

    const outClass = classNames(
      styles.outDiv,
      { [styles.isCurrentOutDiv]: isCurrent }
    );
    const insideClass = classNames(
      styles.insideDiv,
      { [styles.isCurrentInsideDiv]: isCurrent },
      { [styles.notCurrentMonth]: !isCurrentMonth }
    );

    return (
      <div className={outClass}>
        <div className={insideClass}>{number}</div>
      </div>
    );
  }
}

export default NumberCalendar;
